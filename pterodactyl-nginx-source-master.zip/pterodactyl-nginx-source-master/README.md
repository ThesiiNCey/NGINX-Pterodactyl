# pterodactyl-nginx-1.21 (With Modules)

[![Docker Repository on Quay](https://quay.io/repository/tweak4141/pterodactyl-nginx-1.21/status "Docker Repository on Quay")](https://quay.io/repository/tweak4141/pterodactyl-nginx-1.21)

docker pull quay.io/repository/tweak4141/pterodactyl-nginx-1.21
